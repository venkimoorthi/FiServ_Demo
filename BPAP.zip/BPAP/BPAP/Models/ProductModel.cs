﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BPAP.Models
{
    public class ProductModel
    {
        public int Product_ID { get; set; }

        public string Product_Name { get; set; }

        public int Category_ID { get; set; }

        public DateTime Launch_Date { get; set; }

        public int Item_Price { get; set; }

        public int Quantity { get; set; }

        public DateTime UpdatedOn_Date { get; set; }

        public string UpdatedBy_User { get; set; }

    }
}
