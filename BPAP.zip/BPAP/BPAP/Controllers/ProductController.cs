﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Http;
using System.Threading;
using Microsoft.AspNetCore.Cors;
using BPAP.Models;
using BPAP.Service.Abstract;
using log4net;

namespace BPAP.Controllers
{
    [ApiController]
    [Route("api/[controller]")]

    public class ProductController : ControllerBase
    {
        private readonly IProductService _productService;
        public ProductController(IProductService productService)
        {
            _productService = productService;
        }

        [HttpGet]
        [Route("GetAll")]
        public IEnumerable<ProductModel> GetAll()
        {
            
            var valProducts = _productService.GetAllProductAsync();
            if (valProducts == null)
            {
                return null;
            }
            return valProducts;
        }

        // GET: api/Product/1
        [HttpGet]
        [Route("GetById/{Product_ID}")]

        public IActionResult GetByProductId(int Product_ID)
        {
            var getData = _productService.GetProductByIDAsync(Product_ID);
            if (getData == null)
            {
                return null;
            }
            return Ok(getData);
        }

        // POST api/values
        [HttpPost]
        [Route("AddProduct")]
        public IActionResult AddProduct(ProductModel value)
        {
            if (!ModelState.IsValid)
            {
                return null;
            }

            var prodinfo = _productService.AddProduct(value);
            if (prodinfo == null)
            {
                return null;
            }

            return Ok(prodinfo);
        }

        // PUT api/values/5
        [HttpPut]
        [Route("UpdateProduct/{Product_ID}")]
        public IActionResult UpdateProduct(int Product_ID, ProductModel value)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            var prodinfo = _productService.UpdateProduct(Product_ID, value);
            return Ok(prodinfo);
        }

        // DELETE api/values/5
        [HttpDelete]
        [Route("DeleteProduct/{Product_ID}")]
        public IActionResult DeleteProduct(int Product_ID)
        {
            var prodinfo = _productService.GetProductByIDAsync(Product_ID);
            if (prodinfo == null)
            {
                return NotFound();
            }
            var result = _productService.DeleteProduct(Product_ID);
            return Ok(result);
        }

    }
}
