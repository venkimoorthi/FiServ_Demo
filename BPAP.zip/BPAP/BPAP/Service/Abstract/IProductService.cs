﻿using BPAP.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BPAP.Service.Abstract
{
    public interface IProductService
    {
        List<ProductModel> GetAllProductAsync();
        ProductModel GetProductByIDAsync(int id);
        ProductModel AddProduct(ProductModel value);
        ProductModel UpdateProduct(int id, ProductModel value);
        bool DeleteProduct(int id);
    }
}
