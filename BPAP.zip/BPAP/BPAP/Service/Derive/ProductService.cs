﻿using BPAP.Models;
using BPAP.Service.Abstract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication_DBA_Layer.DB;

namespace BPAP.Service.Derive
{
    public class ProductService : IProductService
    {
        public ProductRepo Repo { get; set; }
        public ProductService()
        {
            Repo = ProductRepo.Instance;

        }
        public ProductModel AddProduct(ProductModel value)
        {
            if (Repo.Products.Count > 0)
            {
                var res = Repo.Products.Select(i => i.Product_ID).Max();
                value.Product_ID = res + 1;
            }
            else
            {
                value.Product_ID = 1;
            }
            Repo.Products.Add(value);
            return value;
        }

        public bool DeleteProduct(int id)
        {
            var res = Repo.Products.Where(e => e.Product_ID == id).FirstOrDefault();
            if (res != null)
            {
                Repo.Products.Remove(res);
                return (true);
            }

            return (false);
        }

        public List<ProductModel> GetAllProductAsync()
        {
            //return (repo.Products);
            var data = Repo.Products;
            return data;
        }

        public ProductModel GetProductByIDAsync(int id)
        {
            var res = Repo.Products.Where(e => e.Product_ID == id).FirstOrDefault();
            return res;
        }

        public ProductModel UpdateProduct(int id, ProductModel value)
        {
            var res = Repo.Products.Where(e => e.Product_ID == id).FirstOrDefault();
            value.Product_ID = res.Product_ID;
            Repo.Products.Remove(res);
            Repo.Products.Add(value);
            return value;
        }
    }
}
