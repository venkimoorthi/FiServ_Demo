﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using WebApplication_Shared_Services.Model;

namespace WebApplication_Services.Service
{
    public interface IProductService
    {
        Task<List<Product>> GetAllProductAsync(CancellationToken ct);
        Task<Product> GetProductByIDAsync(int id, CancellationToken ct);
        Task<Product> AddProduct(Product value, CancellationToken ct);
        Task<Product> UpdateProduct(int id, Product value, CancellationToken ct);
        Task<bool> DeleteProduct(int id, CancellationToken ct);
    }
}
