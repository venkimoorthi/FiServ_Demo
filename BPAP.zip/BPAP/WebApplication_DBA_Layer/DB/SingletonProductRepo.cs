﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication_Shared_Services.Model;

namespace WebApplication_DBA_Layer.DB
{
    public sealed class SingletonProductRepo
    {
        private static SingletonProductRepo instance = null;
        private static readonly object padlock = new object();
        public List<Product> Products { get; set; }

        SingletonProductRepo()
        {           
            Products = new List<Product>();
            Products.Add(new Product { Product_ID = 1, Product_Name = "Prod_BPAP_111", Category_ID = 151, Launch_Date = DateTime.Now.Date, Item_Price = 100, Quantity = 100, UpdatedOn_Date = DateTime.Now.Date, UpdatedBy_User = "Test User" });
            Products.Add(new Product { Product_ID = 2, Product_Name = "Prod_BPAP_222", Category_ID = 282, Launch_Date = DateTime.Now.Date, Item_Price = 200, Quantity = 100, UpdatedOn_Date = DateTime.Now.Date, UpdatedBy_User = "Test User" });
            Products.Add(new Product { Product_ID = 3, Product_Name = "Prod_BPAP_333", Category_ID = 343, Launch_Date = DateTime.Now.Date, Item_Price = 300, Quantity = 100, UpdatedOn_Date = DateTime.Now.Date, UpdatedBy_User = "Test User" });
            Products.Add(new Product { Product_ID = 4, Product_Name = "Prod_BPAP_444", Category_ID = 494, Launch_Date = DateTime.Now.Date, Item_Price = 400, Quantity = 100, UpdatedOn_Date = DateTime.Now.Date, UpdatedBy_User = "Test User" });
            Products.Add(new Product { Product_ID = 5, Product_Name = "Prod_BPAP_555", Category_ID = 545, Launch_Date = DateTime.Now.Date, Item_Price = 500, Quantity = 100, UpdatedOn_Date = DateTime.Now.Date, UpdatedBy_User = "Test User" });
        }

        public static SingletonProductRepo Instance
        {
            get
            {
                lock (padlock)
                {
                    if (instance == null)
                    {
                        instance = new SingletonProductRepo();
                    }
                    return instance;
                }
            }
        }
    }
}
