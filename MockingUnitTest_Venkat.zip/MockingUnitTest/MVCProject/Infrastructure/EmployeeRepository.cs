﻿using MVCproject.Core;

namespace MVCproject.Infrastructure
{
    public class EmployeeRepository : IGetDataRepository
    {
        public string GetNameById(int id)
        {
            string name;
            if (id == 1)
            {
                name = "venkat";
            }
            else if (id == 2)
            {
                name = "sakthi";
            }
            else
            {
                name = "Not Found";
            }
            return name;
        }
    }
}
