namespace MVCproject.Core
{
    public interface IGetDataRepository
    {
        string GetNameById(int id);
    }
}
