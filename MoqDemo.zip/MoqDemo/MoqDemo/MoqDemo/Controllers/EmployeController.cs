﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using MoqDemo.Models;
using MoqDemo.Services.Abstract;

namespace MoqDemo.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
  
    public class EmployeController : ControllerBase
    {
      
        private readonly IEmployeeService _employeeService;        
        public EmployeController(IEmployeeService employeeService)
        {
            _employeeService = employeeService;
       
         }

        [HttpGet]
        [Route("GetAll")]
        public async Task<IActionResult> GetAll()
        {
            var empdata = await _employeeService.GetAllEmployeeAsync();
            if (empdata == null)
            {
                return NotFound();
            }
            return Ok(empdata);
        }
        [HttpGet]
        [Route("GetByID/{id}")]
        public async Task<IActionResult> GeByID(int id)
        {
            var empinfo = await _employeeService.GetEmployeeByIDAsync(id);
            if (empinfo == null)
            {
                return NotFound();
            }
            return Ok(empinfo);
        }
        [HttpPost]
        [Route("AddEmp")]
        public IActionResult AddEmp(Emp emp)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            var empadd =  _employeeService.AddEmployee(emp);
            if (empadd)
            {
                return Created("Employee Added successfully", empadd);
            }
            else
                return BadRequest("Employee can not be added");
        }
        // PUT api/values/5
        [HttpPut]
        [Route("UpdateEmployee/{id}")]
        public IActionResult UpdateEmployee(int id, Emp emp)
        {

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            var empinfo =  _employeeService.UpdateEmployee(id, emp);
            return Ok(empinfo);
        }
        public bool TrytestModelValidator(object model)
        {
            return TryValidateModel(model);
        }
        [HttpPut]
        [Route("DeleteEmployee/{id}")]
        public async Task<IActionResult> DeleteEmployee(int id)
        {
            var data = await _employeeService.DeleteEmployee(id);
            if(data ==null)
            {
                return NotFound();
            }
            return Ok(data);
        }


    }
}
