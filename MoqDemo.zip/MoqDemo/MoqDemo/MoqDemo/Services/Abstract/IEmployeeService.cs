﻿using MoqDemo.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MoqDemo.Services.Abstract
{
   public interface IEmployeeService
    {
        
        Task<List<Emp>> GetAllEmployeeAsync();
        //IEnumerable<Emp> GetAll();
        Task<Emp> GetEmployeeByIDAsync(int id);
        bool AddEmployee(Emp value);
        Emp UpdateEmployee(int id, Emp emp);
        Task<Emp> DeleteEmployee(int id);

    }
}
