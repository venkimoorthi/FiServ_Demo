﻿using Microsoft.Extensions.Configuration;
using MoqDemo.DB;
using MoqDemo.Models;
using MoqDemo.Services.Abstract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MoqDemo.Services.Derive
{
    public sealed class EmployeeService : IEmployeeService
    {
        public SingletonEmployeeRepo emprepo { get; set; }
        public EmployeeService()
        {
            emprepo = SingletonEmployeeRepo.Instance;

        }
        public bool AddEmployee(Emp value)
        {
            try
            {
                if (emprepo.Employees.Count > 0)
                {
                    var res = emprepo.Employees.Select(i => i.EmpId).Max();
                    value.EmpId = res + 1;
                }
                else
                {
                    value.EmpId = 1;
                }
                emprepo.Employees.Add(value);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public Task<List<Emp>> GetAllEmployeeAsync()
        {
            var data= Task.FromResult(emprepo.Employees);
            return data;
        }

        public Task<Emp> GetEmployeeByIDAsync(int id)
        {
            var res = emprepo.Employees.Where(e => e.EmpId == id).FirstOrDefault();
            return Task.FromResult(res);
        }

        public Emp UpdateEmployee(int id, Emp emp)
        {          
                var res = emprepo.Employees.Where(e => e.EmpId == id).FirstOrDefault();
                emp.EmpId= res.EmpId;
               emprepo.Employees.Remove(res);
                emprepo.Employees.Add(emp);
                return emp;
            }

        public Task<Emp> DeleteEmployee(int id)
        {
            var res = emprepo.Employees.Where(e => e.EmpId == id).FirstOrDefault();
            if (res != null)
            {
                //emp.EmpId = res.EmpId;
                emprepo.Employees.Remove(res);               
            }
            return Task.FromResult(res);
        }
    }
    }

