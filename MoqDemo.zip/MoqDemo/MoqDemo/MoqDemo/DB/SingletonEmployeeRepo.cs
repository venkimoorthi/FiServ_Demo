﻿using MoqDemo.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MoqDemo.DB
{
    public sealed class SingletonEmployeeRepo
    {
        private static SingletonEmployeeRepo instance = null;
        private static readonly object padlock = new object();
        public List<Emp> Employees { get; set; }

        SingletonEmployeeRepo()
        {
            Employees = new List<Emp>();
            Employees.Add(new Emp { EmpId =1, EmpName ="chaithanya", PhoneNumber = 9568956236, Email="chaithanya@gmail.com" });
            Employees.Add(new Emp { EmpId = 2, EmpName = "divya", PhoneNumber = 8956235689, Email = "divya@gmail.com" });

        }

        public static SingletonEmployeeRepo Instance
        {
            get
            {
                lock (padlock)
                {
                    if (instance == null)
                    {
                        instance = new SingletonEmployeeRepo();
                    }
                    return instance;
                }
            }
        }
    }
}
