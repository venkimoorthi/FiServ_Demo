using Microsoft.AspNetCore.Mvc;
using Moq;
using MoqDemo.Controllers;
using MoqDemo.DB;
using MoqDemo.Models;
using MoqDemo.Services.Abstract;
using MoqDemo.Services.Derive;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;

namespace XUnitTestEmployee
{
    public class EmployeUnitTest
    {
        private readonly Mock<IEmployeeService> _employeeService;

        public EmployeUnitTest()
        {
            _employeeService = new Mock<IEmployeeService>();
        }
        [Fact]
        public void GetAll_Employee_Return_Ok()
        {
            //Arrange
            var controller = new EmployeController(_employeeService.Object);
            var data = new List<Emp>
            {
                new Emp()
                {
                    EmpId=1,EmpName="Jhon",PhoneNumber=9023646235,Email="john@gmail.com"
                },
                new Emp
                {
                     EmpId=2,EmpName="Kiran",PhoneNumber=9023646668,Email="kiran@gmail.com"
                }
            };

            _employeeService.Setup(x => x.GetAllEmployeeAsync()).Returns(Task.FromResult(data));
            //Act
            var response = controller.GetAll().Result;
            //Assert
            Assert.NotNull(response);
        }
        [Fact]
        public void GeByID_Employee_Return_Ok()
        {
            //Arrange  
            var controller = new EmployeController(_employeeService.Object);

            int id = 1;
            Emp emp = new Emp() { EmpId = 1, EmpName = "chaithanya", PhoneNumber = 9632589632, Email = "abc@gmail.com" };
            _employeeService.Setup(x => x.GetEmployeeByIDAsync(id)).Returns(Task.FromResult(emp));
            //Act  
            var data = controller.GeByID(id).Result;
            //Assert  
            var objectResponse = data as ObjectResult;
            Assert.IsType<OkObjectResult>(data);
        }
        [Fact]
        public void GeByID_Employee_Return_NotFoundResult()
        {
            //Arrange  
            var controller = new EmployeController(_employeeService.Object);
            int id = 3;
            _employeeService.Setup(x => x.GetEmployeeByIDAsync(id)).Returns(Task.FromResult<Emp>(null));
            //Act  
            var data = controller.GeByID(id).Result;
            //Assert  
            Assert.IsType<NotFoundResult>(data);
        }
        [Fact]
        public async void GeByID_Employee_Return_MatchResult()
        {
            //Arrange  
            var controller = new EmployeController(_employeeService.Object);
            int id = 2;
            Emp emp = new Emp() { EmpId = 2, EmpName = "divya", PhoneNumber = 8956235689, Email = "xyz@gmail.com" };
            _employeeService.Setup(x => x.GetEmployeeByIDAsync(id)).Returns(Task.FromResult(emp));

            //Act  
            var data = await controller.GeByID(id);

            var objectResponse = data as ObjectResult; //Cast to desired type
            var employ = objectResponse.Value as Emp;

            //Assert  

            Assert.Equal(200, objectResponse.StatusCode);
            Assert.Equal(emp.EmpId, employ.EmpId);
            Assert.Equal(emp.EmpName, employ.EmpName);
            Assert.Equal(emp.Email, employ.Email);

        }
        [Fact]
        public void Task_Add_ValidData_Return_OkResult()
        {
            //Arrange  
            var controller = new EmployeController(_employeeService.Object);
            Emp emps = new Emp() { EmpId = 3, EmpName = "vinay", PhoneNumber = 9632589632, Email = "abc@gmail.com" };
            _employeeService.Setup(x => x.AddEmployee(emps)).Returns(true);

            //Act  
            var response = controller.AddEmp(emps) as CreatedResult;

            //Assert  

            var employ = response.Value as Emp;                   

            Assert.Equal("Employee Added successfully", response.Location);
            Assert.Equal(201, response.StatusCode);

        }


        [Fact]
        public void Task_Update_ValidData_Return_OkResult()
        {
            //Arrange  
            var controller = new EmployeController(_employeeService.Object);
            Emp emp = new Emp() { EmpId = 2, EmpName = "Deepa", PhoneNumber = 8956235689, Email = "xyz@gmail.com" };
            int empId = 2;           
            //Act          
            _employeeService.Setup(x => x.UpdateEmployee(empId, emp)).Returns(emp);
            var data = controller.UpdateEmployee(empId, emp);

            //Assert                  

            var objectResponse = data as ObjectResult; 
            var employ = objectResponse.Value as Emp;

            Assert.Equal(200, objectResponse.StatusCode);
            Assert.Equal(emp.EmpId, employ.EmpId);
            Assert.Equal(emp.EmpName, employ.EmpName);
            Assert.Equal(emp.Email, employ.Email);     
        }
        [Fact]
        public void Task_Delete_Post_Return_OkResult()
        {
            var controller = new EmployeController(_employeeService.Object);
            int empId = 2;
            Emp emp = new Emp() { EmpId = 2, EmpName = "divya", PhoneNumber = 8956235689, Email = "xyz@gmail.com" };
            _employeeService.Setup(x => x.DeleteEmployee(empId)).Returns(Task.FromResult(emp));

            //Act  
            //Act  
            var data = controller.DeleteEmployee(empId).Result;
            //Assert  
            var objectResponse = data as ObjectResult;
            Assert.IsType<OkObjectResult>(data);

        }
        [Fact]
        public void Task_Delete_Return_BadRequestResult()
        {
            //Arrange  
            var controller = new EmployeController(_employeeService.Object);
            int id = 3;
            _employeeService.Setup(x => x.DeleteEmployee(id)).Returns(Task.FromResult<Emp>(null));
            //Act  
            var data = controller.DeleteEmployee(id).Result;
            //Assert  
            Assert.IsType<NotFoundResult>(data);
        }
    }

    }
