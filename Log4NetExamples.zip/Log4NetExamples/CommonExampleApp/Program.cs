﻿using Common.Implementation;
using log4net.Config;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

[assembly: XmlConfigurator(ConfigFile = @"..\..\app.config", Watch = true)]
namespace CommonExampleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            XmlConfigurator.ConfigureAndWatch(new FileInfo(@"..\..\app.config"));
            SimpleCalculator calculator = new CommonExampleApp.SimpleCalculator(SampleLog4NetLogger.Current);
            double result = 0;

            SampleLog4NetLogger.Current.Debug("Adding two correct numbers....");
            result = calculator.Add("23", "56");

            SampleLog4NetLogger.Current.Debug("Adding two numbers with incorrect format....");
            result = calculator.Add("23", "Test");

            SampleLog4NetLogger.Current.Debug("Subtracting two correct numbers....");
            result = calculator.Subtract("1343", "56");

            SampleLog4NetLogger.Current.Debug("Subtracting two numbers with incorrect format....");
            result = calculator.Subtract("1343", "Robin");

            SampleLog4NetLogger.Current.Debug("Multiplying two correct numbers....");
            result = calculator.Multiply("43", "90");

            SampleLog4NetLogger.Current.Debug("Multiplying two numbers with incorrect format....");
            result = calculator.Multiply("43", "Cream");

            SampleLog4NetLogger.Current.Debug("Dividing two correct numbers....");
            result = calculator.Divide("225", "25");

            SampleLog4NetLogger.Current.Debug("Dividing two numbers with incorrect format....");
            result = calculator.Divide("225", "Number");

            SampleLog4NetLogger.Current.Debug("Dividing number by zero....");
            result = calculator.Divide("225", "0");
        }
    }
}
