﻿using Common.Contract;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonExampleApp
{
    public class SimpleCalculator
    {
        private ILogger logger;
        private const string EntryFormat = "Starting Method {0} with Left operand : {1} and Right Operand : {2}";
        private const string SuccessfulExitFormat = "Successfully Finishing Method {0} with Left operand : {1}, Right Operand : {2}, Output : {3}";
        private const string FailedExitFormat = "Finishing with Failure in Method : {0} with Left operand : {1} and Right Operand : {2}";
        private const string ParseFormat = "In Method {0} with Left operand : {1} and Right Operand : {2}, Successfully Parsed {3} number.";
        private const string SuccessfulOutcomeFormat = "In Method {0} with Left operand : {1} and Right Operand : {2}, Operation Successful with Output:  {3}.";
        private const string Left = "left";
        private const string Right = "right";

        public SimpleCalculator(ILogger _logger)
        {
            logger = _logger;
        }

        public double Add(string left, string right)
        {
            double result = 0;
            StackTrace trace = new StackTrace();

            logger.Info(string.Format(EntryFormat, trace.GetFrame(1).GetMethod().Name, left, right));

            try
            {
                double left_Number = double.Parse(left);
                logger.Debug(string.Format(ParseFormat, trace.GetFrame(1).GetMethod().Name, left, right, Left));

                double right_Number = double.Parse(right);
                logger.Debug(string.Format(ParseFormat, trace.GetFrame(1).GetMethod().Name, left, right, Right));

                result = left_Number + right_Number;
                logger.Debug(string.Format(SuccessfulOutcomeFormat, trace.GetFrame(1).GetMethod().Name, left, right, result));
            }
            catch (Exception ex)
            {
                logger.Error(string.Format(FailedExitFormat, trace.GetFrame(1).GetMethod().Name, left, right), ex);
            }

            logger.Info(string.Format(SuccessfulExitFormat, trace.GetFrame(1).GetMethod().Name, left, right, result));

            return result;
        }

        public double Subtract(string left, string right)
        {
            double result = 0;
            StackTrace trace = new StackTrace();

            logger.Info(string.Format(EntryFormat, trace.GetFrame(1).GetMethod().Name, left, right));

            try
            {
                double left_Number = double.Parse(left);
                logger.Debug(string.Format(ParseFormat, trace.GetFrame(1).GetMethod().Name, left, right, Left));

                double right_Number = double.Parse(right);
                logger.Debug(string.Format(ParseFormat, trace.GetFrame(1).GetMethod().Name, left, right, Right));

                result = left_Number - right_Number;
                logger.Debug(string.Format(SuccessfulOutcomeFormat, trace.GetFrame(1).GetMethod().Name, left, right, result));
            }
            catch (Exception ex)
            {
                logger.Error(string.Format(FailedExitFormat, trace.GetFrame(1).GetMethod().Name, left, right), ex);
            }

            logger.Info(string.Format(SuccessfulExitFormat, trace.GetFrame(1).GetMethod().Name, left, right, result));

            return result;
        }

        public double Multiply(string left, string right)
        {
            double result = 0;
            StackTrace trace = new StackTrace();

            logger.Info(string.Format(EntryFormat, trace.GetFrame(1).GetMethod().Name, left, right));

            try
            {
                double left_Number = double.Parse(left);
                logger.Debug(string.Format(ParseFormat, trace.GetFrame(1).GetMethod().Name, left, right, Left));

                double right_Number = double.Parse(right);
                logger.Debug(string.Format(ParseFormat, trace.GetFrame(1).GetMethod().Name, left, right, Right));

                result = left_Number * right_Number;
                logger.Debug(string.Format(SuccessfulOutcomeFormat, trace.GetFrame(1).GetMethod().Name, left, right, result));
            }
            catch (Exception ex)
            {
                logger.Error(string.Format(FailedExitFormat, trace.GetFrame(1).GetMethod().Name, left, right), ex);
            }

            logger.Info(string.Format(SuccessfulExitFormat, trace.GetFrame(1).GetMethod().Name, left, right, result));

            return result;
        }


        public double Divide(string left, string right)
        {
            double result = 0;
            StackTrace trace = new StackTrace();

            logger.Info(string.Format(EntryFormat, trace.GetFrame(1).GetMethod().Name, left, right));

            try
            {
                double left_Number = double.Parse(left);
                logger.Debug(string.Format(ParseFormat, trace.GetFrame(1).GetMethod().Name, left, right, Left));

                double right_Number = double.Parse(right);
                logger.Debug(string.Format(ParseFormat, trace.GetFrame(1).GetMethod().Name, left, right, Right));

                result = left_Number / right_Number;
                logger.Debug(string.Format(SuccessfulOutcomeFormat, trace.GetFrame(1).GetMethod().Name, left, right, result));
            }
            catch (Exception ex)
            {
                logger.Error(string.Format(FailedExitFormat, trace.GetFrame(1).GetMethod().Name, left, right), ex);
            }

            logger.Info(string.Format(SuccessfulExitFormat, trace.GetFrame(1).GetMethod().Name, left, right, result));

            return result;
        }
    }
}
