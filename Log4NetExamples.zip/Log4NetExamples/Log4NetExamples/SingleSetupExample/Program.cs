﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SingleSetupExample
{
    class Program
    {
        static void Main(string[] args)
        {
            XSampleLog4NetLogger.Current.Debug("Hi , This is first log line....");            
            XSampleLog4NetLogger.Current.Debug("And this is last log line....");
        }
    }
}
